using LibraryManagementSystem.Models;
using LibraryManagementSystem.Data;
using Microsoft.Data.SqlClient;

namespace LibraryManagementSystem.Repository;

public class BookRepository
{
    private readonly DBHelper dbHelper = new();

    public void AddBook(Book book)
    {
        using SqlConnection conn = dbHelper.GetConnection();

        conn.Open();

        string query =
            @"INSERT INTO Books
              (Title, ISBN, PublishedYear, Quantity, AuthorID, CategoryID)
              VALUES
              (@Title, @ISBN, @PublishedYear, @Quantity, @AuthorID, @CategoryID)";

        using SqlCommand cmd = new(query, conn);

        cmd.Parameters.AddWithValue("@Title", book.Title);
        cmd.Parameters.AddWithValue("@ISBN", book.ISBN);
        cmd.Parameters.AddWithValue("@PublishedYear", book.PublishedYear);
        cmd.Parameters.AddWithValue("@Quantity", book.Quantity);
        cmd.Parameters.AddWithValue("@AuthorID", book.AuthorID);
        cmd.Parameters.AddWithValue("@CategoryID", book.CategoryID);

        cmd.ExecuteNonQuery();

        Console.WriteLine("Book added successfully!");
    }
}