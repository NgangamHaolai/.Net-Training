namespace LibraryManagementSystem.Models
{
    public class Member 
    { 
        public int MemberID { get; set; } 
        public string MemberName { get; set; } 
        public string Email { get; set; } 
        
        public string Phone { get; set; } 
    }
}