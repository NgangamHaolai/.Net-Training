using Microsoft.Data.SqlClient; 
 
namespace LibraryManagementSystem.Data
{
    public class DBHelper
    {
        private string connectionString =
            "Server=localhost\\SQLEXPRESS; Database=LibraryDB; Trusted_Connection=True; TrustServerCertificate=True;";

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}