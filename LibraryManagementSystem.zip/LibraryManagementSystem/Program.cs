﻿using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repository;

BookRepository repository = new();

while (true)
{
    Console.WriteLine("\n===== Library Management System =====");
    Console.WriteLine("1. Add Book");
    Console.WriteLine("2. Exit");

    Console.Write("Enter choice: ");

    int choice = Convert.ToInt32(Console.ReadLine());

    switch (choice)
    {
        case 1:

            Book book = new();

            Console.Write("Title: ");
            book.Title = Console.ReadLine() ?? "";

            Console.Write("ISBN: ");
            book.ISBN = Console.ReadLine() ?? "";

            Console.Write("Published Year: ");
            book.PublishedYear = Convert.ToInt32(Console.ReadLine());

            Console.Write("Quantity: ");
            book.Quantity = Convert.ToInt32(Console.ReadLine());

            Console.Write("Author ID: ");
            book.AuthorID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Category ID: ");
            book.CategoryID = Convert.ToInt32(Console.ReadLine());

            repository.AddBook(book);

            break;

        case 2:
            return;

        default:
            Console.WriteLine("Invalid choice.");
            break;
    }
}