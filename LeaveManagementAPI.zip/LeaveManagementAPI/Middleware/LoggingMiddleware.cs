using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementAPI.Middleware
{
    public class LoggingMiddleware  // step 18
    {
        private readonly RequestDelegate _next;
        public LoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task Invoke(HttpContext context)
        {
            Console.WriteLine($"Request: {context.Request.Path}");
            await _next(context);
            Console.WriteLine($"Response Status: {context.Response.StatusCode}");
        }
    }
}