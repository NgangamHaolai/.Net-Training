using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using LeaveManagementAPI.Models;

namespace LeaveManagementAPI.Services
{
    public interface IEmployeeService   // step 14
    {
        Task<List<Employee>> GetAllEmployees();
    }
}