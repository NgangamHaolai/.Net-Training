using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementAPI.Services
{
    public class EmployeeService : IEmployeeService //step 15
    {
        private readonly IEmployeeRepository _repository;
        public EmployeeService(IEmployeeRepository repository)
        {
            _repository = repository;
        }   
        public async Task<List<Employee>> GetAllEmployees()
        {
            return await _repository.GetAllAsync();
        }
    }
}