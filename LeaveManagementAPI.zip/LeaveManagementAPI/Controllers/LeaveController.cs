using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LeaveController : ControllerBase
    {
        private readonly ILeaveService _service;
        public LeaveController(ILeaveService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetLeaves()
        {
            return Ok();
        }
        [HttpPost]
        public IActionResult ApplyLeave(LeaveRequest leave)
        {
            return Ok();
        }
        [HttpPut("approve/{id}")]
        public IActionResult Approve(int id)
        {
            return Ok();
        }
        [HttpPut("reject/{id}")]
        public IActionResult Reject(int id)
        {
            return Ok();
        }
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            return Ok();
        }
    }
}