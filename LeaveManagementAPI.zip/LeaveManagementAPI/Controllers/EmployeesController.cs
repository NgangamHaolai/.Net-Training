using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using LeaveManagementAPI.Models;
using LeaveManagementAPI.Services;

namespace LeaveManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EmployeesController : ControllerBase   // step 17
    {
        private readonly IEmployeeService _service;
        public EmployeesController(IEmployeeService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetEmployees()
        {
            var employees = await _service.GetAllEmployees();
            return Ok(employees);
        }

        [HttpPost]  // step 20
        public async Task<IActionResult> CreateEmployee(Employee employee)
        {
            if(!ModelState.IsValid)
                return BadRequest(ModelState);
            return Ok();
        }
    }
}