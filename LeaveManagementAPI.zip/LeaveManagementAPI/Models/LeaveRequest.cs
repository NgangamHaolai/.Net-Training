using System.ComponentModel.DataAnnotations;

namespace LeaveManagementAPI.Models
{
    public class LeaveRequest   // step 7
    {
        public int LeaveRequestId { get; set; }
        public int EmployeeId { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        [Required]
        public DateTime EndDate { get; set; }
        [Required]
        public string Reason { get; set; }
        public string Status { get; set; } = "Pending";
        public Employee Employee { get; set; }
    }
}