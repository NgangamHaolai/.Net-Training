using System.ComponentModel.DataAnnotations;

namespace LeaveManagementAPI.Models
{
    public class Employee   // step 6
    {
        public int EmployeeId { get; set; }
        
        [Required]
        [StringLength(100)]
        public string FirstName { get; set; }

        [Required]
        [StringLength(100)]
        public string LastName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Department { get; set; }
    }
}