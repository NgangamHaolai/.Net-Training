using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankLoanManagement.API.DTOs
{
    public class CustomerResponseDto
    {
        public int CustomerId {get; set;}
        public string FullName {get; set;}
        public string Email {get; set;}
    }
}