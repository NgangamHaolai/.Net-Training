using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankLoanManagement.API.DTOs
{
    public class LoanApplicationCreateDto
    {
        public decimal RequestedAmount {get; set;}
        public int TenureMonths {get; set;}
        public string Purpose {get; set;}
        // public string Status {get; set;}
    }
}