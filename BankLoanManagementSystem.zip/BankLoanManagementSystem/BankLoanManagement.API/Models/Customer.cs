using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankLoanManagement.API.Models
{
    public class Customer
    {
        public int CustomerId {get; set;}
        public string FullName {get; set;}
        public string Email {get; set;}
        public string MobileNumber {get; set;}
        public string Address {get; set;}
        public string PANNumber {get; set;}
        public decimal AnnualIncome {get; set;}
        // private string CreatedDate {get; set;}
    }
}