using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankLoanManagement.API.Models
{
    public class LoanApplication
    {
        public int LoanApplicationId {get; set;}
        public int CustomerId {get; set;}
        public int LoanTypeId {get; set;}
        public decimal RequestedAmount {get; set;}
        public int TenureMonths {get; set;}
        public string Purpose {get; set;}
        // public string ApplicationDate {get; set;}
        public string Status {get; set;}
    }
}