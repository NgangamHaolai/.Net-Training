using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.DTOs;
using BankLoanManagement.API.Models;
using BankLoanManagement.API.Repositories;

namespace BankLoanManagement.API.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _repository;
        public CustomerService(ICustomerRepository repository)
        {
            _repository = repository;
        }
        public async Task<List<Customer>> GetAllCustomersAsync()
        {
            return await _repository.GetAllAsync();
        }
        public async Task<Customer> GetCustomerByIdAsync(int customerId)
        {
            return await _repository.GetByIdAsync(customerId);
        }
        public async Task AddCustomerAsync(CustomerCreateDto dto)
        {
            Customer customer = new Customer
            {
                FullName = dto.FullName,
                Email = dto.Email,
                MobileNumber = dto.MobileNumber,
                AnnualIncome = dto.AnnualIncome
            };
            await _repository.AddAsync(customer);
        }
        public async Task UpdateCustomerAsync(int customerId)
        {
            await _repository.UpdateAsync(customerId);
        }
        public async Task DeleteCustomerAsync(int customerId)
        {
            await _repository.DeleteAsync(customerId);
        }
    }
}