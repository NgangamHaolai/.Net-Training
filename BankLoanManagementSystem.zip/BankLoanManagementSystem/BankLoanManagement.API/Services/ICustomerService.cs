using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Threading.Tasks;
using BankLoanManagement.API.DTOs;
using BankLoanManagement.API.Models;

namespace BankLoanManagement.API.Services
{
    public interface ICustomerService
    {
        Task<List<Customer>> GetAllCustomersAsync();
        Task<Customer> GetCustomerByIdAsync(int customerId);
        Task AddCustomerAsync(CustomerCreateDto dto);
        Task UpdateCustomerAsync(int customerId);
        Task DeleteCustomerAsync(int customerId);
    }
}