using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.Repositories;
using BankLoanManagement.API.Services;
using BankLoanManagement.API.DTOs;
// using Microsoft.EntityFrameworkCore;
using BankLoanManagement.API.Models;

namespace BankLoanManagement.API.Services
{
    public class LoanApplicationService : ILoanApplicationService
    {
        private readonly ILoanApplicationRepository _repository;
        public LoanApplicationService(ILoanApplicationRepository repository)
        {
            _repository = repository;
        }
        public async Task<List<LoanApplication>> GetAllLoanApplicationsAsync()
        {
            return await _repository.GetAllAsync();
        }
        public async Task<LoanApplication> GetLoanApplicationByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }
        public async Task AddLoanApplicationAsync(LoanApplicationCreateDto dto)
        {
            LoanApplication loanApplication = new LoanApplication
            {
                RequestedAmount = dto.RequestedAmount,
                TenureMonths = dto.TenureMonths,
                Purpose = dto.Purpose
            };
            await _repository.AddAsync(loanApplication);
        }
        public async Task UpdateLoanApplicationAsync(int id)
        {
            await _repository.UpdateAsync(id);
        }
        public async Task DeleteLoanApplicationAsync(int id)
        {
            await _repository.DeleteAsync(id);
        }
    }
}