using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.Models;
using BankLoanManagement.API.DTOs;

namespace BankLoanManagement.API.Services
{
    public interface ILoanApplicationService
    {
        Task<List<LoanApplication>> GetAllLoanApplicationsAsync();
        Task<LoanApplication> GetLoanApplicationByIdAsync(int id);
        Task AddLoanApplicationAsync(LoanApplicationCreateDto dto);
        Task UpdateLoanApplicationAsync(int id);
        Task DeleteLoanApplicationAsync(int id);
    }
}