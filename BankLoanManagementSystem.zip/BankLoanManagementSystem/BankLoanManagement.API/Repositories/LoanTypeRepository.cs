using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.Models;
using Microsoft.EntityFrameworkCore;

namespace BankLoanManagement.API.Repositories
{
    public class LoanTypeRepository : ILoanTypeRepository
    {
        private readonly BankDbContext _context;
        public LoanTypeRepository(BankDbContext context)
        {
            _context = context;
        }
        public async Task<List<LoanType>> GetAllAsync()
        {
            return await _context.LoanTypes.ToListAsync();
        }
        public async Task AddAsync(LoanType loanType)
        {
            await _context.LoanTypes.AddAsync(loanType);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(int loanTypeId)
        {
            var loanType = await _context.LoanTypes.FindAsync(loanTypeId);
            _context.LoanTypes.Update(loanType);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int loanTypeId)
        {
            var loanType = await _context.LoanTypes.FindAsync(loanTypeId);
            _context.LoanTypes.Remove(loanType);
            await _context.SaveChangesAsync();
        }
    }
}