using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.Models;

namespace BankLoanManagement.API.Repositories
{
    public interface ILoanApplicationRepository
    {
        // Task<List<LoanApplication>> GetAllLoanApplicationsASync();
        // Task<LoanApplication> GetLoanApplicationByIdAsync(int loanApplicationId);
        // Task AddLoanApplicationAsync(LoanApplication loanApplication);
        // Task UpdateLoanApplicationAsync(int loanApplicationId);
        // Task DeleteLoanApplicationAsync(int loanApplicationId);

        Task<List<LoanApplication>> GetAllAsync();
        Task<LoanApplication> GetByIdAsync(int id);
        Task AddAsync(LoanApplication loanApplication);
        Task UpdateAsync(int id);
        Task DeleteAsync(int id);
    }
}