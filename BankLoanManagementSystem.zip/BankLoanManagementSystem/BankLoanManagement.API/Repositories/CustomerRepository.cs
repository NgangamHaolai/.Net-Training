using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.Models;
// using BankLoanManagement.API.Services;
// using BankLoanManagement.API.Repositories;
using Microsoft.EntityFrameworkCore;

namespace BankLoanManagement.API.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly BankDbContext _context;
        public CustomerRepository(BankDbContext context)
        {
            _context = context;
        }
        public async Task<List<Customer>> GetAllAsync()
        {
            return await _context.Customers.ToListAsync();
        }
        public async Task<Customer> GetByIdAsync(int customerId)
        {
            return await _context.Customers.FindAsync(customerId);
        }
        public async Task AddAsync(Customer customer)
        {
            await _context.Customers.AddAsync(customer);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAsync(int customerId)
        {
            var customer = await _context.Customers.FindAsync(customerId);
            _context.Customers.Update(customer);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(int customerId)
        {
            var customer = await _context.Customers.FindAsync(customerId);
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
        }
    }
}