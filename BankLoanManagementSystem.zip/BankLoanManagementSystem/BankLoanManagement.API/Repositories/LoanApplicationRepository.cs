using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using BankLoanManagement.API.Models;

namespace BankLoanManagement.API.Repositories
{
    public class LoanApplicationRepository : ILoanApplicationRepository
    {
        private readonly BankDbContext _context;
        public LoanApplicationRepository(BankDbContext context)
        {
            _context = context;
        }
        public async Task<List<LoanApplication>> GetAllAsync()
        {
            return await _context.LoanApplications.ToListAsync();
        }
        public async Task<LoanApplication> GetByIdAsync(int id)
        {
            return await _context.LoanApplications.FindAsync(id);
        }
        public async Task AddAsync(LoanApplication loanApplication)
        {
            await _context.LoanApplications.AddAsync(loanApplication);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(int id)
        {
            var loanApplication = await _context.LoanApplications.FindAsync(id);
            _context.LoanApplications.Update(loanApplication);
            await _context.SaveChangesAsync();        
        }
        public async Task DeleteAsync(int id)
        {
            var loanApplication = await _context.LoanApplications.FindAsync(id);
            _context.LoanApplications.Remove(loanApplication);
            await _context.SaveChangesAsync();
        }
    }
}