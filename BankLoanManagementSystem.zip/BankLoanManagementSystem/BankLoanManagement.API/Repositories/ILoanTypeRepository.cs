using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BankLoanManagement.API.Models;

namespace BankLoanManagement.API.Repositories
{
    public interface ILoanTypeRepository
    {
        // Task<List<LoanType>> GetAllLoanTypesAsync();
        // Task AddLoanTypeAsync(LoanType loanType);
        // Task UpdateLoanTypeAsync(int loanTypeId);
        // Task DeleteLoanTypeAsync(int loanTypeId);

        Task<List<LoanType>> GetAllAsync();
        Task AddAsync(LoanType loanType);
        Task UpdateAsync(int id);
        Task DeleteAsync(int id);
    }
}